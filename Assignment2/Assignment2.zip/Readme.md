Assignment2 Readme
Yue Zhang
1.In command line, type”python Assignment2” to run.
Python version : Python 2.7.10

2.Results:
Navie Bayes:
Accuracy for Naive Bayes model before remove stopWords= 0.953974895397
Accuracy for Naive Bayes model after remove stopWords= 0.937238493724

Logistic Regression with L2 regularization and learning rate = 0.0001:
Accuracy for Logistic Regression model with iterations = 4 and alpha = 1.8 before remove stopWords = 0.364016736402
Accuracy for Logistic Regression model with iterations = 4 and alpha = 1.8 after remove stopWords = 0.333682008368
Accuracy for Logistic Regression model with iterations = 19 and alpha = 0.6 before remove stopWords = 0.635983263598
Accuracy for Logistic Regression model with iterations = 19 and alpha = 0.6 after remove stopWords = 0.666317991632
Accuracy for Logistic Regression model with iterations = 15 and alpha = 0.2 before remove stopWords = 0.635983263598
Accuracy for Logistic Regression model with iterations = 15 and alpha = 0.2 after remove stopWords = 0.666317991632
Accuracy for Logistic Regression model with iterations = 8 and alpha = 2.0 before remove stopWords = 0.364016736402
Accuracy for Logistic Regression model with iterations = 8 and alpha = 2.0 after remove stopWords = 0.333682008368
Accuracy for Logistic Regression model with iterations = 4 and alpha = 0.5 before remove stopWords = 0.364016736402
Accuracy for Logistic Regression model with iterations = 4 and alpha = 0.5 after remove stopWords = 0.333682008368
Accuracy for Logistic Regression model with iterations = 9 and alpha = 1.4 before remove stopWords = 0.635983263598
Accuracy for Logistic Regression model with iterations = 9 and alpha = 1.4 after remove stopWords = 0.666317991632
Accuracy for Logistic Regression model with iterations = 6 and alpha = 1.4 before remove stopWords = 0.364016736402
Accuracy for Logistic Regression model with iterations = 6 and alpha = 1.4 after remove stopWords = 0.333682008368
Accuracy for Logistic Regression model with iterations = 6 and alpha = 0.1 before remove stopWords = 0.364016736402
Accuracy for Logistic Regression model with iterations = 6 and alpha = 0.1 after remove stopWords = 0.333682008368
Accuracy for Logistic Regression model with iterations = 18 and alpha = 1.6 before remove stopWords = 0.364016736402
Accuracy for Logistic Regression model with iterations = 18 and alpha = 1.6 after remove stopWords = 0.333682008368
Accuracy for Logistic Regression model with iterations = 17 and alpha = 1.1 before remove stopWords = 0.635983263598
Accuracy for Logistic Regression model with iterations = 17 and alpha = 1.1 after remove stopWords = 0.666317991632