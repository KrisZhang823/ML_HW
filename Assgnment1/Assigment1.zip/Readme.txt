1.Unzip file to local directory.
2.In terminal type "python Assignment1.py 100 30 data_sets1/training_set.csv data_sets1/validation_set.csv data_sets1/test_set.csv no". You will see the result.
